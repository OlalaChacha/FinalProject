﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms
{
    public partial class CreateReceipt : Form
    {
        public CreateReceipt()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //product 1
            if (comboBox1.SelectedIndex == 0)
            {
                textBoxPrice.Text = "20000";
            }
            //product 2
            if (comboBox1.SelectedIndex == 1)
            {
                textBoxPrice.Text = "72000";
            }
            //product 3
            if (comboBox1.SelectedIndex == 2)
            {
                textBoxPrice.Text = "30000";
            }
            //product 4
            if (comboBox1.SelectedIndex == 3)
            {
                textBoxPrice.Text = "4200";
            }
            //product 5
            if (comboBox1.SelectedIndex == 4)
            {
                textBoxPrice.Text = "260000";
            }
            //product 6
            if (comboBox1.SelectedIndex == 5)
            {
                textBoxPrice.Text = "18500";
            }
            //product 7
            if (comboBox1.SelectedIndex == 6)
            {
                textBoxPrice.Text = "43000";
            }
            //product 8
            if (comboBox1.SelectedIndex == 7)
            {
                textBoxPrice.Text = "42000";
            }
            //product 9
            if (comboBox1.SelectedIndex == 8)
            {
                textBoxPrice.Text = "32000";
            }
            //product 10
            if (comboBox1.SelectedIndex == 9)
            {
                textBoxPrice.Text = "32000";
            }
        }
        //Make sure the Input in textbox Quantity only accept number, not characters
        private void textBoxQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }

        
        private void btnAdd_Click(object sender, EventArgs e)
        {

        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            report r = new report();
            r.Show();
        }
    }
}
