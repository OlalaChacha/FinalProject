﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsForms
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            

        }

        private void btnLogin_Click_1(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click_2(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=DESKTOP-19SABVQ\SQLEXPRESS;Initial Catalog=company;Integrated Security=True";
            conn.Open();
            string username = textBoxUsername.Text;
            string password = textBoxPassword.Text;
            SqlCommand cmd = new SqlCommand("SELECT username,password FROM account WHERE username='" + textBoxUsername.Text + "'AND password ='" + textBoxPassword.Text + "'", conn);
            SqlDataAdapter a = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            a.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                Management h = new Management();
                this.Hide();
                h.Show();
            }
            else
            {
                MessageBox.Show("Invalid Username/Password");
            }
            conn.Close();
        }
    }
}
