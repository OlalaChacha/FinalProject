﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsForms
{
    public partial class Management : Form
    {
        public Management()
        {
            InitializeComponent();
        }

        private void Management_Load(object sender, EventArgs e)
        {

        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void informationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Profile x = new Profile();
            x.ShowDialog();
        }

        private void adminToolStripMenuItem_Click(object sender, EventArgs e)
        {
            admin x = new admin();
            x.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CreateReceipt c = new CreateReceipt();
            c.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ViewReceipt v = new ViewReceipt();
            v.ShowDialog();
        }
    }
}
