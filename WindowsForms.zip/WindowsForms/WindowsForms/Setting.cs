﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace WindowsForms
{
    class Setting
    {
        public Setting()
        {
        }
        public DataTable table(string query)
        {
            DataTable dt = new DataTable();
            string connectionS = @"Data Source=DESKTOP-19SABVQ\SQLEXPRESS;Initial Catalog=company;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connectionS);
            
            conn.Open();
            SqlDataAdapter a = new SqlDataAdapter(query,conn);
            a.Fill(dt);
            conn.Close();
            
            return dt;
        } 

        //Add, Edit, Delete
        public void Command(string query)
        {
            string connectionS = @"Data Source=DESKTOP-19SABVQ\SQLEXPRESS;Initial Catalog=company;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connectionS);
            
            conn.Open();
            SqlCommand s = new SqlCommand(query,conn);
            s.ExecuteNonQuery();
            conn.Close();
        }
    }
}
