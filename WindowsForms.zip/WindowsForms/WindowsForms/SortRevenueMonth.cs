﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsForms
{
    public partial class SortRevenueMonth : Form
    {
        public SortRevenueMonth()
        {
            InitializeComponent();
            ViewListRevenue();
        }

        void ViewListRevenue()
        {
            string connectionS = @"Data Source=DESKTOP-19SABVQ\SQLEXPRESS;Initial Catalog=company;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connectionS);
            string query = "select distinct*, riNumber*price as Total from receiptInfo, receipt, product where receiptInfo.rId = receipt.rId AND product.pId=receiptInfo.pId and Month(RTime)=5";

            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            DataTable dt = new DataTable();
            SqlDataAdapter a = new SqlDataAdapter(cmd);
            a.Fill(dt);
            conn.Close();
            dataGridView1.DataSource = dt;

        }

        //select distinct*, riNumber*price as Total from receiptInfo, receipt, product where receiptInfo.rId = receipt.rId AND product.pId=receiptInfo.pId and Month(RTime)=5
        private void SortRevenueMonth_Load(object sender, EventArgs e)
        {

        }
    }
}
