﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace WindowsForms
{
    public partial class ViewReceipt : Form
    {
        public ViewReceipt()
        {
            InitializeComponent();
            ViewListReceipt();
        }

        void ViewListReceipt()
        {
            string connectionS = @"Data Source=DESKTOP-19SABVQ\SQLEXPRESS;Initial Catalog=company;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connectionS);
            string query = "select distinct* from receipt r,receiptInfo ri where r.rId = ri.rId";

            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            DataTable dt = new DataTable();
            SqlDataAdapter a = new SqlDataAdapter(cmd);
            a.Fill(dt);
            conn.Close();
            dataGridView1.DataSource = dt;

        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ViewReceipt_Load(object sender, EventArgs e)
        {

        }
    }
}
