﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading.Tasks;


namespace WindowsForms
{
    public partial class admin : Form
    {
        public admin()
        {
            InitializeComponent();
            ListAccount();
            ViewListRevenue();
        }

        void ListAccount()
        {
            string connectionS = @"Data Source=DESKTOP-19SABVQ\SQLEXPRESS;Initial Catalog=company;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connectionS);
            string query = "SELECT* FROM account";

            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            DataTable dt = new DataTable();
            SqlDataAdapter a = new SqlDataAdapter(cmd);
            a.Fill(dt);
            conn.Close();
            dataGridView1.DataSource = dt;

        }
        // Declare 
        Setting s = new Setting();
        calculate c;

        private void admin_Load(object sender, EventArgs e)
        {
            deleteTextBox();
        }
        private void deleteTextBox()
        {
            textBoxUsername.Text = "";
            textBoxPassword.Text = "";
            comboBoxPosition.SelectedIndex = -1;
        }

        //Get value
        private void getValue()
        {
            string _username = textBoxUsername.Text;
            string _password = textBoxPassword.Text;
            string _position = comboBoxPosition.Text;
            c = new calculate(_username,_password,_position);
        }

        //Check new adding input
        private bool checkTextBox()
        {
            if(comboBoxPosition.SelectedIndex == -1)
            {
                MessageBox.Show("Fill the blank");
                return false;
            }
            if (textBoxUsername.Text == "")
            {
                MessageBox.Show("Fill the blank");
                return false;
            }
            if (textBoxPassword.Text == "")
            {
                MessageBox.Show("Fill the blank");
                return false;
            }
            return true;
        }
        //add
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (checkTextBox())
            {
                getValue();
                string query = "INSERT INTO account VALUES ('" + c.username + "',"+ c.password +"," + c.position+ ")";
                try
                {
                    s.Command(query);
                    MessageBox.Show("Success");
                    admin_Load(sender,e);
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Fail");
                }
            
            }
        }
        //edit
        private void btnEdit_Click(object sender, EventArgs e)
        {

        }
        //delete
        private void btnDelete_Click(object sender, EventArgs e)
        {
            /*if(dataGridView1.Rows.Count > 1)
            { 
            string s = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            string query = "DELETE account";
            query += "WHERE username = '" + s + "'";
            try
            {
                s.Command(query);
                //MessageBox.Show("Success");
                admin_Load(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fail");
            }

            }*/
        }
        void ViewListRevenue()
        {
            string connectionS = @"Data Source=DESKTOP-19SABVQ\SQLEXPRESS;Initial Catalog=company;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connectionS);
            string query = "select  distinct*,riNumber*price as Total from receiptInfo, receipt, product where receiptInfo.rId = receipt.rId AND product.pId=receiptInfo.pId";

            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            DataTable dt = new DataTable();
            SqlDataAdapter a = new SqlDataAdapter(cmd);
            a.Fill(dt);
            conn.Close();
            dataGridViewRevenue.DataSource = dt;

        }
        private void dataGridViewRevenue_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnView_Click(object sender, EventArgs e)
        {
            SortRevenueMonth s = new SortRevenueMonth();
            s.ShowDialog();
        }
    }
}
