﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsForms
{
    class calculate
    {
        private string _username;
        private string _password;
        private string _position;

        public calculate() { }

        public calculate(string username, string password, string position) {
            _username = username;
            _password = password;
            _position = position;

        }
        public string username { get => _username; set => _username = value; }
        public string password { get => _password; set => _password = value; }
        public string position { get => _position; set => _position = value; }
    
        //Calcute Total
        
    
    
    
    }
}
