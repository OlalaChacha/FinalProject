﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;

namespace WindowsForms
{
    public partial class report : Form
    {
        public report()
        {
            InitializeComponent();
        }
        Setting s = new Setting();
        private void report_Load(object sender, EventArgs e)
        {
            reportViewer1.LocalReport.ReportEmbeddedResource = "WindowsForms.Report1.rdlc";
            ReportDataSource r = new ReportDataSource();
            r.Name = "DataSet1";
            reportViewer1.LocalReport.DataSources.Add(r);
            this.reportViewer1.RefreshReport();
        }
    }
}
